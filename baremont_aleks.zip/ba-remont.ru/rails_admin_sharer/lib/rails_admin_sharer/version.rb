module RailsAdminSharer
  VERSION = "0.0.1"
end
