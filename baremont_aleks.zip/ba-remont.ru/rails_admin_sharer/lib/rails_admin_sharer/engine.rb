module RailsAdminSharer
  class Engine < ::Rails::Engine
  end
end
