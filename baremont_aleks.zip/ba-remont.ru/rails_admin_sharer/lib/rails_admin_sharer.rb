require "rails_admin_sharer/engine"
require "rails_admin_sharer/sharer"

module RailsAdminSharer
end
