require 'test_helper'

class CustomAdminControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
