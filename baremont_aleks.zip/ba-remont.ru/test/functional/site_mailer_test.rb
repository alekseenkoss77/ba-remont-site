require 'test_helper'

class SiteMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
