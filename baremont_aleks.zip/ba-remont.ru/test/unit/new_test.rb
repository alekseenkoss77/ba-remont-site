require 'test_helper'

class NewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
