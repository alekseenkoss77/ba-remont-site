require 'test_helper'

class VacancyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
