require 'test_helper'

class NewseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
