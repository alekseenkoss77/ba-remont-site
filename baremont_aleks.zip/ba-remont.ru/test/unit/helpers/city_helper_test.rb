require 'test_helper'

class CityHelperTest < ActionView::TestCase
end
