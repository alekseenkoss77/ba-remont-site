require 'test_helper'

class TidingsHelperTest < ActionView::TestCase
end
