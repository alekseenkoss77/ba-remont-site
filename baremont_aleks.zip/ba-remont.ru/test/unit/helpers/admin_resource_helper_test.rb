require 'test_helper'

class AdminResourceHelperTest < ActionView::TestCase
end
