require 'test_helper'

class CustomAdminHelperTest < ActionView::TestCase
end
