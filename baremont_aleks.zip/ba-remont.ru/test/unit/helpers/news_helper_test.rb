require 'test_helper'

class NewsHelperTest < ActionView::TestCase
end
