require 'test_helper'

class UrlHelperTest < ActionView::TestCase
end
