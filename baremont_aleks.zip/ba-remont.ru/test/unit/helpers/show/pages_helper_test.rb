require 'test_helper'

class Show::PagesHelperTest < ActionView::TestCase
end
