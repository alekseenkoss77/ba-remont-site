require 'test_helper'

class ImgTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
