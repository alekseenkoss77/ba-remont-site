module TidingsHelper
end
