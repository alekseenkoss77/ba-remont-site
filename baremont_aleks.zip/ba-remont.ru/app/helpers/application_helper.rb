#encoding: utf-8
module ApplicationHelper
  def title(page_title)
    content_for(:title) { page_title }
  end

  def current_city?(city)
    if session[:city] == city
      true
    else
      false
    end
  end

  def current_city
    session[:city]
  end

  def show_menu(menu)
    if menu == :top
      @out = get_pages(:top_menu)
    end
    if menu == :main
      @out = get_pages(:main_menu)
    end
    return @out
  end

  def city_choose
    @cities = City.all
    out = ''
    @cities.each do |city|
      out += "<li>#{link_to city.name, url_for(
          :subdomain => city.subdomain,
          :controller => :city,
          :action => :chose
      )}</li>"
    end
    out.html_safe
  end

  #method that render last news in the main page
  def view_last_news_helper
    out = ''
    @news = Newse.joins(:city).where('cities.subdomain' => current_city).order('created_at').limit(8)
    if !@news.empty?
      @news.each do |news|
        out += "<li>"
        out += "<em class='date'>#{news.created_at}</em>"
        out += "#{link_to news.name, news_path(news.id)}"
        out += "</li>"
      end
    else
      out += "<li>Извините, новостей не добавлено!"
      out += "</li>"
    end
    out.html_safe
  end

  #method that render catalog in the layout
  def view_catalog_helper
    @catalog = Article.joins(:city).where('cities.subdomain' => current_city)
    out = "<ul class='menu'>"
    if !@catalog.empty?
      @catalog.each do |article|
        out += "<li>#{link_to article.name, article_path(article.permalink)}</li>"
      end
    else
      out += "<li>В каталоге выбранного города нет уcлуг!</li>"
    end
    out += "</ul>"
    out.html_safe
  end

  private

  def get_pages(menu)
    out = ''
    @pages = Page.joins(:city).where('cities.subdomain' => current_city).where(menu => true)
    @pages.each do |item|
      out = out + "<li>#{link_to ('<span><i>'+item.name+'</i></span>').html_safe ,
          url_for(
              :controller => :pages,
              :action => :show,
              :id => item.permalink,
              :subdomain => current_city
          )
      } </li>"
    end
    return out.html_safe
  end

end
