# encoding: utf-8
class SiteMailer < ActionMailer::Base
  default from: "from@example.com"

  def send_vacancy(vacancy, city)
    @vacancy = vacancy
    @city  = city
    mail(
        :to => "alekseenkoss@gmail.com",
        :subject => "Новая вакансия"
    )
  end

  def send_order(order, city)
    @order = order
    @city = city
    mail(
        :to => "alekseenkoss@gmail.com",
        :subject => "Новая заявка"
    )
  end
end
