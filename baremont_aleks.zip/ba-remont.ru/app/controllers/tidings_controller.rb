class TidingsController < ApplicationController
  def index
    @tiding = Newse.joins(:city).where('cities.subdomain' => current_city )

  end

  def show
     @tiding = Newse.joins(:city).where('cities.subdomain = ? and newses.id = ?', current_city, params[:id] )
  end
end
