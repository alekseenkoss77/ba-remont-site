class PagesController < ApplicationController

  def show
    #@page = Page.find_by_permalink!(params[:id])
    @page = Page.joins(:city).where('cities.subdomain = ? AND pages.permalink = ?', current_city, params[:id]).limit(1)
  end
end
