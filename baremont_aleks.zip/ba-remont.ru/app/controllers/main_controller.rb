class MainController < ApplicationController
#  before_filter :set_city_from_ip

  def index
    @domain = request.subdomain
    #redirect by ipgeobase
    #set_city_from_ip
  end

  def copy
    @cat = Article.joins(:city).where('cities.subdomain' => :tomsk)
    p "="*100
    p @cat
    p "="*100
    @cat.each do |article|
      #@obj = Article.new(article)
      #@obj.city.subdomain = "seversk"
      #@obj.save
      obj = Article.new
      obj.name = article.name
      obj.title = article.title
      obj.content = article.content
      obj.permalink = article.permalink
      obj.position = article.position
      obj.preview_text = article.preview_text
      obj.save


    end
    #redirect_to :root_url
    render :text => "Copi is ok"
  end
end
