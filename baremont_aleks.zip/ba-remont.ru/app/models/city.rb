class City < ActiveRecord::Base
   attr_accessible :title, :content, :name, :subdomain

   has_many :newse, :dependent => :destroy, :inverse_of => :city
   has_many :articles, :dependent => :destroy, :inverse_of => :city
   has_many :pages, :dependent => :destroy, :inverse_of => :city

end
