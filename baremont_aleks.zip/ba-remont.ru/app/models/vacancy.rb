class Vacancy < ActiveRecord::Base
   attr_accessible :fio,
                   :speciality,
                   :city_id   ,
                   :telephone ,
                   :stage     ,
                   :inventory ,
                   :car       ,
                   :study     ,
                   :old       ,
                   :comment


end
