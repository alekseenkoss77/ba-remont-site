$(document).ready(function(){
	$("#system-message_block").delay("2000").slideToggle("slow"); 
    });

