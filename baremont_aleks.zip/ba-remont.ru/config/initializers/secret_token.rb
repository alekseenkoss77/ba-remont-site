# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsApp::Application.config.secret_token = 'cb8fbb79c63df6134c959740070dff13d787f4cadfa620309e1855c647a4a0865b9ad28369148b2119f5b12ac2b7f859622f3b0d5580feab1fa6badea57ef6a1'
